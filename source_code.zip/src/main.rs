// Using std::io
use std::io;

// Function to calculate the absolute value of a number
fn abs(num: i32) -> i32 {

    // i32 integer abs_num variable
    let abs_num: i32;

    // Calculating the absoute value of the number
    if num < 0 {
        abs_num = (num + (0 - (2 * num))) as i32;
    } else {
        abs_num = num as i32;
    }

    // Returning the absolute value of the number
    abs_num
}

// Function to tell if a number is even
fn is_even(num: i32) -> bool {
    
    // Calculating if the number is even
    // And returning the coresponding value
    if num % 2 == 0 {
        return true;
    } else {
        return false;
    }
}

// Function to tell if a number is prime
fn is_prime(num: i32) -> bool {

    // Absolute value of num
    let abs_num: i32 = abs(num);

    // Bool variable prime (true by default)
    let mut prime: bool = true;

    // Calculating if the number is prime
    for i in 2..abs_num {
        if abs_num % i == 0 {
            prime = false;
            break;
        }
    }

    // 0 or 1 cases
    if num == 0 || num == 1 {
        prime = false;
    }

    // Returning prime
    prime
}

fn div(num: i32) -> String {

    // Absolute value of num
    let abs_num: i32 = abs(num);
    
    // div String variable
    let mut div: String = String::new();

    // Calculating the divisors of the number
    for i in (0 - (abs_num + 1))..(abs_num + 1) {
        
        // Division by 0 error fix
        if i == 0 {
            continue;
        }

        if abs_num % i == 0 {
            div.push_str(&format!("{}, ", i) as &str);
        }
    }

    // Returning div
    div
}

// Main function
fn main() {

    // num String variable
    let mut num: String = String::new();

    // User input
    println!("Enter a number: ");
    io::stdin().read_line(&mut num).expect("ERROR: Failed to read line.");

    // Type conversion
    let num: i32 = num.trim().parse().expect("ERROR: Failed to perform type conversion.");

    // Analyzer output (1)
    println!("{} is even: {}", num, is_even(num));
    println!("{} is prime: {}", num, is_prime(num));
    println!("Divisors of {}: {}", num, div(num));

    // mult String variable
    let mut mult: String = String::new();

    // Calculation of multiples
    for i in -20..21 {
        mult.push_str(&format!("{}, ", i * num) as &str);
    }

    // Analyzer output (2)
    println!("Multiples of {}: {}", num, mult);
}